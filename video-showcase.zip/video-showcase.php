<?php
/*
Plugin Name: Video Showcase
Description: The Video Showcase plugin provides a comprehensive solution for creating a video library on your WordPress site, akin to popular streaming services like Netflix. Users can upload videos, add titles, descriptions, and thumbnails, categorize and tag content, and display videos attractively on the front-end. It is fully responsive, making it accessible and visually appealing on all devices..
Version: 1.0
Author: Majdi M. S. Awad
License: MIT
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class VideoShowcase {
    public function __construct() {
        add_action('init', array($this, 'create_custom_post_type'));
        add_action('add_meta_boxes', array($this, 'add_video_meta_boxes'));
        add_action('save_post', array($this, 'save_video_meta_boxes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_handle_video_upload', array($this, 'handle_video_upload'));
        add_action('wp_ajax_nopriv_handle_video_upload', array($this, 'handle_video_upload'));
        add_shortcode('video_showcase', array($this, 'render_video_showcase'));
        add_filter('template_include', array($this, 'include_template_functions'));
    }

    // Create custom post type for videos
    public function create_custom_post_type() {
        $labels = array(
            'name' => 'Videos',
            'singular_name' => 'Video',
            'add_new' => 'Add New Video',
            'add_new_item' => 'Add New Video',
            'edit_item' => 'Edit Video',
            'new_item' => 'New Video',
            'all_items' => 'All Videos',
            'view_item' => 'View Video',
            'search_items' => 'Search Videos',
            'not_found' => 'No videos found',
            'not_found_in_trash' => 'No videos found in Trash',
            'menu_name' => 'Videos'
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'rewrite' => array('slug' => 'videos'),
            'taxonomies' => array('category', 'post_tag')
        );

        register_post_type('video', $args);
    }

    // Add meta boxes for video details
    public function add_video_meta_boxes() {
        add_meta_box(
            'video_details',
            'Video Details',
            array($this, 'render_video_meta_box'),
            'video',
            'normal',
            'high'
        );
    }

    // Render the video meta box
    public function render_video_meta_box($post) {
        wp_nonce_field('save_video_details', 'video_details_nonce');
        $video_url = get_post_meta($post->ID, '_video_url', true);
        $video_image = get_post_meta($post->ID, '_video_image', true);
        ?>
        <p>
            <label for="video_url">Video URL:</label>
            <input type="text" name="video_url" id="video_url" value="<?php echo esc_attr($video_url); ?>" class="widefat">
        </p>
        <p>
            <label for="video_image">Video Image URL:</label>
            <input type="text" name="video_image" id="video_image" value="<?php echo esc_attr($video_image); ?>" class="widefat">
        </p>
        <p>
            <label for="video_upload">Upload Video:</label>
            <input type="file" name="video_upload" id="video_upload" accept="video/*" class="widefat">
        </p>
        <?php
    }

    // Save the meta box data
    public function save_video_meta_boxes($post_id) {
        if (!isset($_POST['video_details_nonce']) || !wp_verify_nonce($_POST['video_details_nonce'], 'save_video_details')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['video_url'])) {
            update_post_meta($post_id, '_video_url', sanitize_text_field($_POST['video_url']));
        }

        if (isset($_POST['video_image'])) {
            update_post_meta($post_id, '_video_image', sanitize_text_field($_POST['video_image']));
        }

        if (!empty($_FILES['video_upload']['name'])) {
            $supported_types = array('video/mp4', 'video/ogg', 'video/webm');
            $arr_file_type = wp_check_filetype(basename($_FILES['video_upload']['name']));
            $uploaded_type = $arr_file_type['type'];

            if (in_array($uploaded_type, $supported_types)) {
                $upload = wp_upload_bits($_FILES['video_upload']['name'], null, file_get_contents($_FILES['video_upload']['tmp_name']));
                if (isset($upload['error']) && $upload['error'] != 0) {
                    wp_die('There was an error uploading your video. The error is: ' . $upload['error']);
                } else {
                    update_post_meta($post_id, '_video_url', $upload['url']);
                }
            } else {
                wp_die("The file type that you've uploaded is not an MP4, OGG, or WebM.");
            }
        }
    }

    // Enqueue scripts and styles
    public function enqueue_scripts() {
        wp_enqueue_style('video-showcase-style', plugin_dir_url(__FILE__) . 'css/style.css');
        wp_enqueue_script('video-showcase-script', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), null, true);
    }

    // Handle video uploads via AJAX
    public function handle_video_upload() {
        // Handle the video upload logic here
    }

    // Render video showcase using shortcode
    public function render_video_showcase() {
        ob_start();
        ?>
        <div class="video-showcase">
            <?php
            $args = array('post_type' => 'video', 'posts_per_page' => -1);
            $query = new WP_Query($args);
            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    $video_url = get_post_meta(get_the_ID(), '_video_url', true);
                    $video_image = get_post_meta(get_the_ID(), '_video_image', true);
                    ?>
                    <div class="video-item">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo esc_url($video_image); ?>" alt="<?php the_title(); ?>">
                            <h2><?php the_title(); ?></h2>
                        </a>
                        <p><?php the_excerpt(); ?></p>
                    </div>
                    <?php
                endwhile;
            else :
                echo '<p>No videos found.</p>';
            endif;
            wp_reset_postdata();
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // Include template files
    public function include_template_functions($template_path) {
        if (get_post_type() == 'video') {
            if (is_single()) {
                if ($theme_file = locate_template(array('single-video.php'))) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path(__FILE__) . 'templates/single-video.php';
                }
            } elseif (is_archive()) {
                if ($theme_file = locate_template(array('archive-video.php'))) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path(__FILE__) . 'templates/archive-video.php';
                }
            }
        }
        return $template_path;
    }
}

new VideoShowcase();
<?php get_header(); ?>
<div class="video-content">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            $video_url = get_post_meta(get_the_ID(), '_video_url', true);
            ?>
            <h1><?php the_title(); ?></h1>
            <video controls>
                <source src="<?php echo esc_url($video_url); ?>" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="video-description">
                <?php the_content(); ?>
            </div>
            <?php
        endwhile;
    else :
        echo '<p>No video found.</p>';
    endif;
    ?>
</div>
<?php get_footer(); ?>

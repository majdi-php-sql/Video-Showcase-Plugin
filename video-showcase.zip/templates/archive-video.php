<?php get_header(); ?>
<div class="video-showcase">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            $video_url = get_post_meta(get_the_ID(), '_video_url', true);
            $video_image = get_post_meta(get_the_ID(), '_video_image', true);
            ?>
            <div class="video-item">
                <a href="<?php the_permalink(); ?>">
                    <img src="<?php echo esc_url($video_image); ?>" alt="<?php the_title(); ?>">
                    <h2><?php the_title(); ?></h2>
                </a>
                <p><?php the_excerpt(); ?></p>
            </div>
            <?php
        endwhile;
    else :
        echo '<p>No videos found.</p>';
    endif;
    ?>
</div>
<?php get_footer(); ?>

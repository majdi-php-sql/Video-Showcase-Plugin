jQuery(document).ready(function($) {
    $('#video_upload').on('change', function() {
        var formData = new FormData();
        formData.append('action', 'handle_video_upload');
        formData.append('file', $('#video_upload')[0].files[0]);

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                alert('Video uploaded successfully!');
            },
            error: function(response) {
                alert('Failed to upload video.');
            }
        });
    });
});
